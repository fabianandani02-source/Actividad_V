#ifndef MODE_DMA_H
#define MODE_DMA_H

/* Ejecuta modo que inicia una transferencia DMA para enviar todo el buffer.
   - Env�a un encabezado textual.
   - Inicia la transferencia DMA del buffer pool_values reinterpretado como bytes.
   - Espera a la finalizaci�n y luego env�a un mensaje de fin.
   - Mientras DMA trabaja, el LED parpadea (demostraci�n de CPU no bloqueado).
*/
void mode_dma_send(void);

#endif /* MODE_DMA_H */
